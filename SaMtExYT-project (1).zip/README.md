# SaMtExYT

Lokalni Android VPN/DNS filter za poznate reklamne i tracking domene.

Napomena: DNS filtriranje ne može pouzdano ukloniti YouTube oglase kada se oglasi i video sadržaj isporučuju kroz iste domene. Ova aplikacija zato ne garantuje blokiranje svih YouTube oglasa.

Build:
`./gradlew :app:assembleDebug`
