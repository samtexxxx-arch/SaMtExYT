package com.samtexyt

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

class AdBlockVpnService : VpnService() {
    private var vpn: ParcelFileDescriptor? = null
    private val pool = Executors.newSingleThreadExecutor()

    private val blocked = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com",
        "ads.youtube.com", "youtubeads.googleusercontent.com"
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpn == null) startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        vpn = Builder()
            .setSession("SaMtExYT")
            .addAddress("10.10.0.2", 32)
            .addRoute("10.10.0.1", 32)
            .addDnsServer("10.10.0.1")
            .setBlocking(false)
            .establish()
        val fd = vpn ?: return
        pool.execute { dnsLoop(fd) }
    }

    private fun dnsLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        while (vpn != null) {
            try {
                val n = input.read(buf)
                if (n < 28 || !isIpv4UdpDns(buf, n)) continue
                val query = buf.copyOf(n)
                val name = dnsName(query, n) ?: continue
                val responseDns = if (blocked.any { name == it || name.endsWith(".$it") }) {
                    buildNxDomainDns(query, n)
                } else {
                    forwardDns(query, n)
                } ?: continue
                output.write(responseDns)
            } catch (_: Exception) { break }
        }
    }

    private fun forwardDns(packet: ByteArray, n: Int): ByteArray? {
        val ipHeader = (packet[0].toInt() and 0x0F) * 4
        val udpOffset = ipHeader
        val dnsOffset = udpOffset + 8
        if (dnsOffset >= n) return null
        val dns = packet.copyOfRange(dnsOffset, n)
        val socket = DatagramSocket()
        return try {
            protect(socket)
            socket.soTimeout = 2500
            val server = InetAddress.getByName("1.1.1.1")
            socket.send(DatagramPacket(dns, dns.size, server, 53))
            val resp = ByteArray(4096)
            val dp = DatagramPacket(resp, resp.size)
            socket.receive(dp)
            buildUdpIpv4Response(packet, n, resp.copyOf(dp.length), ipHeader)
        } finally { socket.close() }
    }

    private fun buildUdpIpv4Response(req: ByteArray, n: Int, dns: ByteArray, ipHeader: Int): ByteArray {
        val udpLen = 8 + dns.size
        val out = ByteArray(ipHeader + udpLen)
        System.arraycopy(req, 0, out, 0, ipHeader)
        for (i in 0..3) { val x=out[12+i]; out[12+i]=out[16+i]; out[16+i]=x }
        out[2] = ((out.size ushr 8) and 255).toByte(); out[3] = (out.size and 255).toByte()
        out[8] = 64
        out[9] = 17
        out[ipHeader] = req[ipHeader+2]; out[ipHeader+1] = req[ipHeader+3]
        out[ipHeader+2] = req[ipHeader]; out[ipHeader+3] = req[ipHeader+1]
        out[ipHeader+4] = ((udpLen ushr 8) and 255).toByte(); out[ipHeader+5] = (udpLen and 255).toByte()
        out[ipHeader+6] = 0; out[ipHeader+7] = 0
        System.arraycopy(dns, 0, out, ipHeader+8, dns.size)
        out[10]=0; out[11]=0
        val ipSum = checksum(out, 0, ipHeader)
        out[10]=(ipSum ushr 8).toByte(); out[11]=ipSum.toByte()
        val udpSum = udpChecksum(out, ipHeader, udpLen)
        out[ipHeader+6]=(udpSum ushr 8).toByte(); out[ipHeader+7]=udpSum.toByte()
        return out
    }

    private fun buildNxDomainDns(req: ByteArray, n: Int): ByteArray? {
        val ipHeader = (req[0].toInt() and 0x0F) * 4
        val dnsOffset = ipHeader + 8
        if (dnsOffset + 12 > n) return null
        val dns = req.copyOfRange(dnsOffset, n)
        dns[2] = (dns[2].toInt() or 0x80).toByte()
        dns[3] = (dns[3].toInt() or 0x83).toByte()
        for (i in 4 until 12) dns[i] = 0
        return buildUdpIpv4Response(req, n, dns, ipHeader)
    }

    private fun isIpv4UdpDns(b: ByteArray, n: Int): Boolean {
        val h = (b[0].toInt() and 0x0F) * 4
        return n >= h + 8 && (b[0].toInt() and 0xF0) == 0x40 &&
            (b[9].toInt() and 255) == 17 &&
            ((b[h+2].toInt() and 255) shl 8 or (b[h+3].toInt() and 255)) == 53
    }

    private fun dnsName(b: ByteArray, n: Int): String? {
        val h = (b[0].toInt() and 0x0F) * 4
        var p = h + 8 + 12
        val parts = mutableListOf<String>()
        while (p < n && b[p].toInt() != 0) {
            val len = b[p].toInt() and 255
            if (len > 63 || p + len >= n) return null
            parts += String(b, p + 1, len, Charsets.US_ASCII)
            p += len + 1
        }
        return parts.joinToString(".").lowercase()
    }

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i < off + len - 1) { sum += ((b[i].toInt() and 255) shl 8) + (b[i+1].toInt() and 255); i += 2 }
        if (i < off + len) sum += (b[i].toInt() and 255) shl 8
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun udpChecksum(b: ByteArray, udpOff: Int, udpLen: Int): Int {
        var sum = 0L
        // IPv4 pseudo-header: source + destination + protocol + UDP length.
        for (i in 12 until 20 step 2) {
            sum += ((b[i].toInt() and 255) shl 8) + (b[i + 1].toInt() and 255)
        }
        sum += 17
        sum += udpLen
        var i = udpOff
        while (i < udpOff + udpLen - 1) {
            sum += ((b[i].toInt() and 255) shl 8) + (b[i + 1].toInt() and 255)
            i += 2
        }
        if (i < udpOff + udpLen) sum += (b[i].toInt() and 255) shl 8
        while (sum ushr 16 != 0L) sum = (sum and 0xFFFF) + (sum ushr 16)
        val result = sum.inv().toInt() and 0xFFFF
        return if (result == 0) 0xFFFF else result
    }

    override fun onDestroy() {
        vpn?.close(); vpn = null
        pool.shutdownNow()
        super.onDestroy()
    }
}
