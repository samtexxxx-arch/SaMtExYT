package com.samtexyt

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        val title = TextView(this).apply { text = "SaMtExYT"; textSize = 30f }
        status = TextView(this).apply { text = "Zaštita je isključena"; textSize = 18f; setPadding(0, 40, 0, 40) }
        val button = Button(this).apply { text = "UKLJUČI ZAŠTITU" }
        button.setOnClickListener {
            val prepare = VpnService.prepare(this)
            if (prepare != null) startActivityForResult(prepare, 100)
            else startService(Intent(this, AdBlockVpnService::class.java))
        }
        box.addView(title); box.addView(status); box.addView(button)
        setContentView(box)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK)
            startService(Intent(this, AdBlockVpnService::class.java))
    }
}
