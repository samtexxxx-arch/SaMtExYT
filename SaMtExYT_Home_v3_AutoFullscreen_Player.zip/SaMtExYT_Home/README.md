# SaMtExYT – Home Screen v1

Novi početni ekran:
- SaMtExYT branding i crveno S
- velika welcome kartica
- kategorije: Muzika, Sport, Gaming, Filmovi
- Nedavno gledano
- Popularno
- donja navigacija
- tamna moderna tema

Player ostaje vlastiti Media3/ExoPlayer player iz prethodne verzije.
