package com.samtexyt.player

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.startButton).setOnClickListener { openPlayer() }
        findViewById<View>(R.id.searchButton).setOnClickListener { openPlayer() }
    }

    private fun openPlayer() {
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}
