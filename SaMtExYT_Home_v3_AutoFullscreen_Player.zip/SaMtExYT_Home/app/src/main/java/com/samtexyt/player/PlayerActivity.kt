package com.samtexyt.player

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var setupPanel: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestFullscreen()
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        urlInput = findViewById(R.id.urlInput)
        setupPanel = findViewById(R.id.setupPanel)

        findViewById<Button>(R.id.playButton).setOnClickListener { playUrl() }
        findViewById<Button>(R.id.exitButton).setOnClickListener { finish() }

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
    }

    private fun playUrl() {
        val raw = urlInput.text.toString().trim()
        if (raw.isEmpty()) {
            urlInput.error = "Unesi video URL"
            return
        }
        player.setMediaItem(MediaItem.fromUri(Uri.parse(raw)))
        player.prepare()
        player.play()
        playerView.useController = true

        // Odmah nakon pritiska na Play prelazimo u pravi fullscreen video režim.
        setupPanel.visibility = View.GONE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        requestFullscreen()
    }

    private fun requestFullscreen() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) requestFullscreen()
    }

    override fun onBackPressed() {
        if (setupPanel.visibility == View.GONE) {
            setupPanel.visibility = View.VISIBLE
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            requestFullscreen()
            player.pause()
        } else {
            super.onBackPressed()
        }
    }

    override fun onStop() {
        super.onStop()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
